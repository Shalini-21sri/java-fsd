package rentMyCam.io;


		//a class named camera is created here
		public class Camera {

			private int Rent; 
				
			public int getRent() {
				return Rent;
			}
			
			public void setRent(int rent) {
				Rent = rent;
			}
			// class variables are declared
			String CamName;
			String Model;
			int Rent;
			
			// Constructor 
		public Camera(String CamName,String Model,int Rent) 
			{
				this.CamName =CamName;
				this.Model = Model;
				this.Rent = Rent;
				
			}
			// used to write methods
			void Display() {
				System.out.println(CamName+" "+"Added");
			}
	}


