package rentMyCam.io;
import java.util.ArrayList;
import java.util.Scanner;

public class LoginPage {

	public static void main(String[] args) {
		// Welcome Screen
				ArrayList<Camera> list=new ArrayList<Camera>();

				System.out.println("+--------------------------------------+");
				System.out.println("| WELCOME TO CAMERA RENTAL APPLICATION |");
				System.out.println("+--------------------------------------+");
				Scanner sc = new Scanner(System.in);
				String UserId;
				System.out.println("PLEASE LOGIN TO CONTINUE\n");
	            System.out.println("ENTER USERNAME :\n");
				UserId = sc.next();
				// if the user id is correct then it is allowed to proceed further
				if(UserId.equals("Shalini")) {
					Menu(list);
				}
				else {
					System.out.println("INCORRECT USERNAME. TRY AGAIN!!");
				}
			}
				// This is main menu
				public static void Menu(ArrayList<Camera> list) {
				int choice;
				System.out.println("\n1.MY CAMERA\n2.RENT A CAMERA\n3.VIEW ALL CAMERAS\n4.MY WALLET\n5.EXIT\n");
				System.out.println("\nENTER YOUR CHOICE :");
				Scanner sc = new Scanner(System.in);
				choice = sc.nextInt();
				switch (choice) {
				case 1:
					// this calls mycam method 
					MyCamera.MyCam(list);
					break;
				case 2:
					// for rent
					RentACamera.Rent(list);			
					break;
				case 3:
					// for view
					ViewAllCams.View( list);
					break;
				case 4:
					// to perform operations related to wallet
					MyWallet.Wallet(list);
					break;
				case 5:
					System.out.println("EXIT");
					break;	
				default:
					throw new IllegalArgumentException("INCORRECT CHOICE : " + choice);
				}
			
		}
			
}


